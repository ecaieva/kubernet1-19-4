# cat load-image.sh 
#!/bin/bash
ls /root/kubeadm-images-1.19.4 > /root/images-list.txt
cd /root/kubeadm-images-1.19.4
for i in $(cat /root/images-list.txt)
do
     docker load -i $i
done
